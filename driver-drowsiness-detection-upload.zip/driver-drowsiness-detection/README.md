# Real-Time Driver Drowsiness Detection Using Spatial-Temporal Deep Learning

This repository contains the documentation and initial project structure for a video-based driver drowsiness detection research project using a CNN-LSTM approach and the UTA-RLDD dataset.

## Project status

**In progress — proposed methodology and paper draft.**

The CNN-LSTM implementation, trained model weights, and measured evaluation results must be added after implementation and experiments are completed. No model accuracy or performance result is claimed in this repository yet.

## Project objective

Investigate whether combining:
- CNN-based spatial feature extraction from video frames, and
- LSTM-based temporal sequence learning

can help classify driver states into alert, low-vigilance, and drowsy categories.

## Repository structure

```text
driver-drowsiness-detection/
├── README.md
├── requirements.txt
├── .gitignore
├── paper/
│   └── main.tex
├── src/
│   └── README.md
├── data/
│   └── README.md
└── notebooks/
    └── README.md
```

## Dataset

The project plans to use the University of Texas at Arlington Real-Life Drowsiness Dataset (UTA-RLDD).

The dataset files are not included in this GitHub repository. Store the dataset locally or in an authorized cloud drive and follow its license/usage terms. Do not upload large video files or private data to GitHub.

See [`data/README.md`](data/README.md) for notes.

## Paper

The LaTeX paper source is in [`paper/main.tex`](paper/main.tex). Open it in Overleaf or compile it with a LaTeX distribution that includes IEEEtran, TikZ, PGFPlots, and the packages listed in the source.

**Before academic submission:** verify every bibliography entry against its original publication and replace planned/placeholder experimental results with actual measured results.

## Setup

Create a Python environment, then install dependencies:

```bash
python -m venv .venv
```

Activate it:

- Windows: `.venv\Scripts\activate`
- macOS/Linux: `source .venv/bin/activate`

Install packages:

```bash
pip install -r requirements.txt
```

The requirements file provides common libraries for the planned video-processing and deep-learning workflow. Actual implementation scripts will be added to `src/`.

## Planned workflow

1. Inspect and organize the dataset.
2. Extract frames and preprocess video.
3. Create subject-independent train/validation/test splits.
4. Train a CNN frame-classification baseline.
5. Train a CNN-LSTM sequence model.
6. Evaluate accuracy, precision, recall, macro F1, confusion matrix, inference time, and FPS.
7. Test webcam inference only after offline evaluation.

## Important

Do not commit dataset videos, model checkpoints, virtual environments, API keys, passwords, or personal information.
