# Source code

This folder is reserved for the project's Python implementation.

Planned modules (add them when implemented):
- `preprocess.py` — video loading, frame sampling, resizing, and normalization.
- `dataset.py` — sequence dataset and subject-wise data splits.
- `models.py` — CNN feature extractor and LSTM classifier.
- `train.py` — model training loop.
- `evaluate.py` — metrics and confusion matrix.
- `inference.py` — video/webcam inference.

These scripts are not included yet because the implementation and experimental configuration have not been finalized. Do not present this folder as a completed working implementation until the scripts have been written and tested.
