# Dataset notes

The project plans to use the UTA-RLDD dataset.

Do not upload the dataset videos to this repository. The recordings are large and may be subject to dataset access and usage terms. Keep them in your authorized Google Drive or local storage.

Suggested local organization (not committed to GitHub):

```text
data/
├── raw/
├── extracted_frames/
└── processed_sequences/
```

Keep participant identity consistent when creating subject-independent train/validation/test splits to avoid data leakage. Check the official dataset documentation for the correct fold protocol and labels.
