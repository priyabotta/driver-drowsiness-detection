# Notebooks

Use this folder for exploratory analysis and experiments, for example:
- dataset inspection,
- frame extraction checks,
- class distribution analysis,
- model training experiments,
- evaluation plots.

Add notebooks here after creating and testing them. Avoid committing notebooks that contain private paths, credentials, or copies of the full dataset.
